create function add_offers_id_to_average_ratings_offers() returns trigger
    language plpgsql
as
$$
DECLARE

BEGIN
    INSERT INTO average_ratings_offers (offer_id) VALUES (NEW.id);

    RETURN NEW;
END;
$$;

alter function add_offers_id_to_average_ratings_offers() owner to knryeurfkvlajn;

