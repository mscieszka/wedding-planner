create function calculate_offers_average() returns trigger
    language plpgsql
as
$$
DECLARE
    data CURSOR IS SELECT offer_id, AVG(rating) AS avg FROM ratings GROUP BY offer_id;
BEGIN
    FOR record IN data
    LOOP
        UPDATE average_ratings_offers SET avg = record.avg WHERE offer_id = record.offer_id;
    END LOOP;

    RETURN NEW;
END;
$$;

alter function calculate_offers_average() owner to knryeurfkvlajn;

